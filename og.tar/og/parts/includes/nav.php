<?php 
 echo ' 
<nav>
<script
  src="https://code.jquery.com/jquery-3.5.1.js"
  integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="
  crossorigin="anonymous">
</script>
<script>
    $( document ).ready(function() {
        var mybodyid = $(".art_id_body").attr("id");
        var myartid = "#art" + mybodyid;
        console.log("mybodyid is " + mybodyid);
        console.log("myartid is " + myartid);
        $(myartid).attr("id", "iamhere");
    });
</script>
<ul>
    <li id="art1"><a href="index.php">Article I</a></li>
    <li id="art2"><a href="ii.php">Article II</a></li>
    <li id="art3"><a href="iii.php">Article III</a></li>
    <li id="art4"><a href="iv.php">Article IV</a></li>
    <li id="art5"><a href="v.php">Article V</a></li>
    <li id="art6"><a href="vi.php">Article VI</a></li>
    <li id="art7"><a href="vii.php">Article VII</a></li>
    <li id="art8"><a href="amendments.php">Amendments</a></li>
</ul>
</nav>'

?>
