 <?php 
 echo '<footer>
 <p>This version of the United States Constitution was adapted from <a href="http://www.house.gov/">U.S. House of Representatives</a> website. <a href="https://www.archives.gov/founding-docs/constitution">Learn more about the United States Constitution at <strong>The National Archives</strong> online exhibit</a>.</p> </footer>'

?>
